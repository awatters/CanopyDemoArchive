#------------------------------------------------------------------------------
#  Copyright (c) 2013, Enthought, Inc.
#  All rights reserved.
#------------------------------------------------------------------------------

from traits.api import List, Unicode
from enaml.widgets.field import Field

class AutocompleteField(Field):
    """ An autocomplete text field

    """

    # The list of possible autocomplete values
    items = List(Unicode)

    #--------------------------------------------------------------------------
    # Initialization
    #--------------------------------------------------------------------------
    def snapshot(self):
        """ Returns the dict of creation attributes for the combo box.

        """
        snap = super(AutocompleteField, self).snapshot()
        snap['items'] = self.items
        return snap

    def bind(self):
        """ A method called after initialization which allows the widget
        to bind any event handlers necessary.

        """
        super(AutocompleteField, self).bind()
        self.on_trait_change(self._send_items, 'items, items_items')

    def _send_items(self):
        """ Send the 'set_items' action to the client widget.

        """
        content = {'items': self.items}
        self.send_action('set_items', content)

