#------------------------------------------------------------------------------
#  Copyright (c) 2013, Enthought, Inc.
#  All rights reserved.
#------------------------------------------------------------------------------

from .autocomplete_field import AutocompleteField
from .spinner import Spinner
from .popup import Popup
from .embed_widget import EmbedWidget

def register_widgets():
    from enaml.qt.qt_widget_registry import QtWidgetRegistry
    from .qt.qt_autocomplete_field import QtAutocompleteField
    from .qt.qt_spinner import QtSpinner
    from .qt.qt_popup import QtPopup
    from .qt.qt_embed_widget import QtEmbedWidget

    QtWidgetRegistry.register('AutocompleteField', lambda: QtAutocompleteField, 'portfolio')
    QtWidgetRegistry.register('Spinner', lambda: QtSpinner, 'portfolio')
    QtWidgetRegistry.register('Popup', lambda: QtPopup, 'portfolio')
    QtWidgetRegistry.register('EmbedWidget', lambda: QtEmbedWidget, 'portfolio')
