""" Sets up a context for evaluating expressions.
"""

import numpy as np
