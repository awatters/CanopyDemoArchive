#------------------------------------------------------------------------------
#  Copyright (c) 2013, Enthought, Inc.
#  All rights reserved.
#------------------------------------------------------------------------------

from traits.api import Instance, Int, Enum, Tuple

from enaml.widgets.window import Window

class Popup(Window):
    """ The Popup container, which gives a popup with similar styling to
        OS X/iOS
    """

    anchor = Enum('bottom', ('left', 'right', 'top', 'bottom'))

    radius = Int(10)
    arrow = Int(20)
    relative_pos = Tuple((0.5, 0.5))

    def show(self, parent=None):
        self._prep_window(parent)
        self.set_visible(True)
