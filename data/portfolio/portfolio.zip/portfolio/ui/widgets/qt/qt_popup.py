
import sys

from enaml.qt.qt_window import QtWindow, QWindowLayout

from .q_popup_widget import QPopupWidget

class QtPopup(QtWindow):
    """ A QT4 implementation of Popup
    """

    #--------------------------------------------------------------------------
    # Setup methods
    #--------------------------------------------------------------------------
    def create_widget(self, parent, tree):
        """ Create the underlying QPopupWidget

        """
        return QPopupWidget(parent)

    def create(self, tree):
        """ Creates the underlying Control.

        """
        super(QtPopup, self).create(tree)
        self.widget().setLayout(QWindowLayout())

        self.set_radius(shell.radius)
        self.set_anchor(shell.anchor)
        self.set_arrow(shell.arrow)
        self.set_relative_pos(shell.relative_pos)

    #--------------------------------------------------------------------------
    # Implementation
    #--------------------------------------------------------------------------
    def set_visible(self, visible):
        """ Show or hide the widget
        """
        if visible: self.widget().show()
        else:  self.widget().hide()

    def set_anchor(self, anchor):
        self.widget().setAnchor(anchor)

    def set_arrow(self, arrow):
        self.widget().setArrowSize(arrow)

    def set_radius(self, radius):
        self.widget().setRadius(radius)

    def set_relative_pos(self, pos):
        self.widget().setRelativePos(pos)
