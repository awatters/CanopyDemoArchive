#------------------------------------------------------------------------------
#  Copyright (c) 2013, Enthought, Inc.
#  All rights reserved.
#------------------------------------------------------------------------------

from os import path

from enaml.qt.qt.QtCore import QSize
from enaml.qt.qt.QtGui import QLabel, QMovie

from enaml.qt.qt_control import QtControl

class QtSpinner(QtControl):
    """ Qt implementation of the spinner control
    """

    #--------------------------------------------------------------------------
    # Setup methods
    #--------------------------------------------------------------------------
    def create_widget(self, parent, tree):
        """ Create the underlying label

        """
        return QLabel(parent)

    def create(self, tree):
        """ Create the underlying control.
        """
        super(QtSpinner, self).create(tree)
        spinner_file = path.join(path.dirname(__file__),'spinner.gif')
        self._movie = movie = QMovie(spinner_file, parent=self.widget())
        movie.setCacheMode(QMovie.CacheAll)
        movie.setScaledSize(QSize(16, 16))
        if tree['spinning']:
            self._start_movie()

    #--------------------------------------------------------------------------
    # Message Handling
    #--------------------------------------------------------------------------
    def on_action_set_spinning(self, content):
        """ Handle the 'set_spinning' action from the Enaml widget

        """
        self.set_spinning(content['spinning'])

    #--------------------------------------------------------------------------
    # Widget Update Methods
    #-------------------------------------------------------------------------- 
    def set_spinning(self, val):
        """ The change handler for the 'spinning' attribute
        """
        if val:
            self._start_movie()
        else:
            self._stop_movie()

    def _start_movie(self):
        self.widget().setMovie(self._movie)
        self._movie.start()

    def _stop_movie(self):
        self.widget().setMovie(None)
        self._movie.stop()

