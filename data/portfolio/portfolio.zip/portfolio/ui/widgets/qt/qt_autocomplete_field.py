#------------------------------------------------------------------------------
#  Copyright (c) 2013, Enthought, Inc.
#  All rights reserved.
#------------------------------------------------------------------------------

from os.path import join, dirname
from enaml.qt.qt.QtGui import QCompleter, QPixmap, QToolButton, QIcon, QStyle
from enaml.qt.qt.QtCore import Qt

from enaml.qt.qt_field import QtFocusLineEdit, QtField

class QtSearchEdit(QtFocusLineEdit):
    def __init__(self, parent=None):
        super(QtSearchEdit, self).__init__(parent)
        self._horizontalMargin, self._verticalMargin = 2, 1
        left, top, right, bottom = self.getTextMargins()

        self._q_button = searchButton = QToolButton(self)
        searchButton.setIcon(QIcon(QPixmap(join(dirname(__file__), 'search.png'))))
        searchButton.setStyleSheet("QToolButton {border: none; padding: 0px; }")

        frameWidth = self.style().pixelMetric(QStyle.PM_DefaultFrameWidth)

        self._c_button = clearButton = QToolButton(self)
        clearButton.setIcon(QIcon(QPixmap(join(dirname(__file__), 'close.png'))))
        clearButton.setCursor(Qt.ArrowCursor)
        clearButton.setStyleSheet("QToolButton {border: none; padding: 0px; }")
        clearButton.hide()
        clearButton.clicked.connect(self.clear)
        self.textChanged.connect(self.updateCloseButton)
        self.returnPressed.connect(self.selectAll)

        self.setTextMargins(left+searchButton.sizeHint().width()+frameWidth, top,
                            right+clearButton.sizeHint().width()+frameWidth, bottom)

        msz = self.minimumSizeHint()
        self.setMinimumSize(
            max(msz.width(), searchButton.sizeHint().width() + clearButton.sizeHint().width() + frameWidth * 4 + 2),
            max(msz.height(), searchButton.sizeHint().height() + clearButton.sizeHint().height() + frameWidth * 4 + 2))

    def resizeEvent(self, event):
        sz = self._q_button.sizeHint()
        sz2 = self._c_button.sizeHint()
        frameWidth = self.style().pixelMetric(QStyle.PM_DefaultFrameWidth)
        rect = self.rect()
        self._q_button.move(frameWidth*2,
                          (rect.bottom() - sz.height())/2 + frameWidth)
        self._c_button.move(rect.right() - sz.width() - frameWidth,
                          (rect.bottom() - sz.height())/2 + frameWidth)
        return super(QtSearchEdit, self).resizeEvent(event)

    def updateCloseButton(self, text):
        self._c_button.setVisible(not text == '')

class QtAutocompleteField(QtField):
    """ A Qt implementation of an Enaml Autocomplete field

    """
    #--------------------------------------------------------------------------
    # Setup Methods
    #--------------------------------------------------------------------------
    def create_widget(self, parent, tree):
        """ Creates the underlying QLineEdit widget.

        """
        return QtSearchEdit(parent)

    def create(self, tree):
        """ Create and initialize the underlying widget.

        """
        super(QtAutocompleteField, self).create(tree)
        self._completer = completer = QCompleter(tree['items'],parent=self.widget())
        completer.setCompletionMode(QCompleter.PopupCompletion)
        completer.setCaseSensitivity(Qt.CaseInsensitive)

        self.widget().setCompleter(completer)

    #--------------------------------------------------------------------------
    # Message Handlers
    #--------------------------------------------------------------------------
    def on_action_set_items(self, content):
        self.set_items(content['items'])

    #--------------------------------------------------------------------------
    # Message Handlers
    #--------------------------------------------------------------------------
    def set_items(self, items):
        # Set up the Qt Completer with the list
        self._completer.model().setStringList(items)
