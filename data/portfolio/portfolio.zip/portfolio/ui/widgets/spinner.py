#------------------------------------------------------------------------------
#  Copyright (c) 2013, Enthought, Inc.
#  All rights reserved.
#------------------------------------------------------------------------------

from traits.api import Bool

from enaml.widgets.control import Control

class Spinner(Control):
    """ A widget which displays a spinning wait image

    """
    #: Is the spinner running
    spinning = Bool

    hug_width = 'required'
    hug_height = 'required'

    #--------------------------------------------------------------------------
    # Initialization
    #--------------------------------------------------------------------------
    def snapshot(self):
        """ Create the snapshot for the widget.

        """
        snap = super(Spinner, self).snapshot()
        snap['spinning'] = self.spinning
        return snap

    def bind(self):
        """ Bind the change handlers for the widget.

        """
        super(Spinner, self).bind()
        self.publish_attributes('spinning')

