
# Enthought library imports
from traits.api import HasTraits, implements, Event, Int, Callable

from i_data_manager import IDataManager

class DataManager(HasTraits):
    """
    Base class for financial data managers
    """

    implements(IDataManager)

    data_ready = Event

    def get_metadata(self, ticker, metadata):
        """ Request asset data for a particular ticker
        """
        raise NotImplementedError()

    def get_price_history(self, ticker):
        """ Request price history data for a particular ticker
        """
        raise NotImplementedError()
