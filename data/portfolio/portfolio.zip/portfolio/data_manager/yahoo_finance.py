import shelve
from datetime import datetime

# Enthought library imports
from traits.api import implements, Instance, Event
from enaml.application import deferred_call

# Local imports
from .cacheing_decorators import lru_cache
from .asynchttp import AsyncHTTPConnection
from .async_loader import AsyncLoader

from .i_data_manager import IDataManager
from .data_manager import DataManager
from portfolio.core.assets import ASSETS_CACHE


class YahooDataManager(DataManager):

    implements(IDataManager)

    loader = Instance(AsyncLoader)

    new_metadata = Event()

    #### IDataManager interface ###########################################

    def supported_metadata(self):
        return YahooMetadataRequest._codes.keys()

    @lru_cache()
    def get_metadata(self, ticker, metadata=None):
        """ Request asset data for a particular ticker

            Parameters
            ---------
            ticker: string
                The stock ticker

            metadata: list
                A list of requested metadata. The supported set of data is:
                    'price'
                    'change'
                    'volume'
                    'avg_daily_volume'
                    'stock_exchange'
                    'market_cap'
                    'book_value'
                    'ebitda'
                    'dividend_per_share'
                    'dividend_yield'
                    'earnings_per_share'
                    '52_week_high'
                    '52_week_low'
                    '50day_moving_avg'
                    '200day_moving_avg'
                    'price_earnings_ratio'
                    'price_earnings_growth_ratio'
                    'price_sales_ratio'
                    'price_book_ratio'
                    'short_ratio'
        """
        datastore = shelve.open(ASSETS_CACHE)
        # shelve doesn't like unicode
        ticker = str(ticker)
        if ticker in datastore and hasattr(datastore[ticker], '50day_moving_avg_change'):
            if metadata is None:
                metadata = self.supported_metadata()
            self._retrieve_metadata(ticker, datastore[ticker], metadata)
        else:
            # Schedule a request to get the tile
            self.loader.put(YahooMetadataRequest(self._metadata_received, ticker, metadata))
        datastore.close()

    def get_price_history(self, ticker):
        """ Request price history data for a particular ticker
        """
        self.loader.put(YahooPriceRequest(self._price_received, ticker))

    #### Public interface #################################################


    ### Private interface ##################################################

    def _metadata_received(self, ticker, metadata):
        metadata['metadata_timestamp'] = datetime.now()
        self.new_metadata = (ticker, metadata)

    def _retrieve_metadata(self, ticker, asset, metadata_names):
        """ extract metadata from a cached asset
        """
        metadata = {}
        for key in metadata_names:
            if hasattr(asset, key):
                metadata[key] = getattr(asset, key)
        self.new_metadata = (ticker, metadata)

    def _price_received(self, ticker, data):
        print ticker, data


class YahooMetadataRequest(AsyncHTTPConnection):
    host = 'download.finance.yahoo.com'
    port = 80

    _codes = {
        'price': 'l1',
        'change': 'c1',
        'percent_change': 'p2',
        'volume': 'v',
        'avg_daily_volume': 'a2',
        'stock_exchange': 'x',
        'market_cap': 'j1',
        'book_value': 'b4',
        'ebitda': 'j4',
        'dividend_per_share': 'd',
        'dividend_yield': 'y',
        'earnings_per_share': 'e',
        '52_week_high': 'k',
        '52_week_low': 'j',
        '50day_moving_avg': 'm3',
        '50day_moving_avg_change': 'm8',
        '200day_moving_avg': 'm4',
        '200day_moving_avg_change': 'm6',
        'price_earnings_ratio': 'r',
        'price_earnings_growth_ratio': 'r5',
        'price_sales_ratio': 'p5',
        'price_book_ratio': 'p6',
        'short_ratio': 's7'
       }

    _reverse_codes = dict([(v,k) for k,v in _codes.iteritems()])

    def __init__(self, handler, ticker, metadata=None):
        AsyncHTTPConnection.__init__(self, self.host, self.port)
        self.handler = handler
        self._ticker = ticker
        # Strip out any unsupported metadata
        self._metadata = metadata

        if metadata:
            # strip out any unsupported metadata
            metadata = filter(lambda f: f in self._codes, metadata)
            flags = [self._codes.get(flag, '') for flag in metadata]
        else:
            flags = self._codes.values()
        self._flags = flags
        #self.set_debuglevel(1)

    def handle_connect(self):
        AsyncHTTPConnection.handle_connect(self)

        url = '/d/quotes.csv?s=%s&f=%s'%(self._ticker, ''.join(self._flags))
        self.putrequest("GET", url)
        self.endheaders()
        self.getresponse()

    def handle_response(self):
        if self.response.status == 200:
            values = self.response.body.strip().replace('"','').split(',')
            data = dict((self._reverse_codes[flag], value) for flag, value in zip(self._flags, values))
            deferred_call(self.handler,
                             self._ticker,
                             data)
        self.close()

    def __str__(self):
        return "YahooRequest for %s"%str(self._ticker)

    def __repr__(self):
        return str(self)


class YahooPriceRequest(AsyncHTTPConnection):
    host = 'ichart.yahoo.com'
    port = 80

    def __init__(self, handler, ticker, start_date=None, end_date=None):
        AsyncHTTPConnection.__init__(self, self.host, self.port)
        self.handler = handler
        self._ticker = ticker

        self._start_date = start_date
        self._end_date = end_date
        self.set_debuglevel(1)

    def handle_connect(self):
        AsyncHTTPConnection.handle_connect(self)
        start, end = self._start_date, self._end_date
        url = '/table.csv?s=%s&'%self._ticker
        #url = ('/table.csv?s=%s&'%self._ticker +
        #  'd=%s&' % str(int(end[4:6]) - 1) + \
        #  'e=%s&' % str(int(end[6:8])) + \
        #  'f=%s&' % str(int(end[0:4])) + \
        #  'g=d&' + \
        #  'a=%s&' % str(int(start[4:6]) - 1) + \
        #  'b=%s&' % str(int(start[6:8])) + \
        #  'c=%s&' % str(int(start[0:4])) + \
        #  'ignore=.csv')

        self.putrequest("GET", url)
        self.endheaders()
        self.getresponse()

    def handle_response(self):
        if self.response.status == 200:
            print self.response.body
            days = self.response.body.split('\n')
            data = [day[:-2].split(',') for day in days]
            deferred_call(self.handler,
                             self._ticker,
                             data)
        self.close()

    def __str__(self):
        return "YahooPriceRequest for %s"%str(self._ticker)

    def __repr__(self):
        return str(self)
