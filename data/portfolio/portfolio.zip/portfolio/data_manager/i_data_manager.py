
# Enthought library imports
from traits.api import Interface

class IDataManager(Interface):
    """
    Interface for financial data source
    """

    def get_metadata(self, ticker, metadata):
        """ Request asset data for a particular ticker
        """

    def get_price_history(self, ticker):
        """ Request price history data for a particular ticker
        """
