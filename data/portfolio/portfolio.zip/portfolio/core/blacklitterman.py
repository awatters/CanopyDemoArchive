""" Black-Litterman model implementation.

Kelsey Jordahl
Time-stamp: <Mon Jul 15 15:16:04 IST 2013>

Copyright (c) 2013, Enthought, Inc.
All rights reserved.
"""
import numpy as np
from scipy import linalg

from traits.api import (
    HasTraits, Property, Float, List, Tuple, String, cached_property, Function,
    Array, Instance, on_trait_change)

from portfolio.core.assets import Portfolio


class Scenario(HasTraits):
    """ Defines a scenario or "view portfolio" to be applied as a
    Bayesian condition to infer the posterior distribution of returns
    on a portfolio.

    positive_filter is a function that takes two arguments, asset and criteria,
    and returns True if the asset matches the criteria.  Assets that match
    positive_filter will have positive weights.

    negative_filter is the same, but defines assets that will get
    negative weights in the view portfolio.

    Filters will be applied to a portfolio in the model to create
    appropriate size vectors and matrices for calculating model
    returns.
    """
    name = Property(String)
    excess_return = Float
    confidence = Float
    positive_filter = Function
    negative_filter = Function

    def _set_name(self, name):
        self._name = name

    def _get_name(self):
        if hasattr(self, '_name'):
            return self._name
        else:
            return '%s outperform %s' % (self.positive_criteria,
                                         self.negative_criteria)

    def __repr__(self):
        return 'Scenario(%s)' % self.name

    def __str__(self):
        return self.name


class BlackLitterman(HasTraits):
    """ Implement the Black-Litterman model
    """
    # model parameters
    delta = Float(2.5)  # Risk aversion parameter (=2.5 HL [1999])
    tau = Float(0.05)   # uncertainty in prior (=0.05 HL [1999])

    risk_free_rate = Float(0.02)
    sharpe_ratio = Property(Array(Float),
                            depends_on=['expected_returns',
                                        'portfolio:standard_deviation'])
    # 
    portfolio = Instance(Portfolio)
    scenarios = List(Instance(Scenario))
    equilibrium_weights = Property(Array, depends_on='portfolio')
    equilibrium_returns = Property(Array, depends_on='delta, portfolio')
    overall_expected_return = Property(Float,
                                       depends_on='weights, expected_returns')
    stdev = Property(Float, depends_on='portfolio, weights')
    weights = Array
    expected_returns = Array
    conditionals = Property(Tuple(Array, Array, Array), depends_on="scenarios")

    def _get_equilibrium_weights(self):
        return self.portfolio.weights

    def _get_equilibrium_returns(self):
        sigma = self.portfolio.covariance_matrix
        weq = self.equilibrium_weights
        return weq.dot(self.delta * sigma)

    @cached_property
    def _get_overall_expected_return(self):
        """ Expected return for the entire portfolio
        """
        return self.weights.dot(self.expected_returns)

    @cached_property
    def _get_stdev(self):
        """ Standard deviation of the entire portfolio
        """
        _m = np.outer(self.weights, self.weights) * self.portfolio.covariance_matrix
        return np.sqrt(_m.sum())

    def _get_sharpe_ratio(self):
        return (self.expected_returns - self.risk_free_rate) / self.portfolio.standard_deviation

    def _get_conditionals(self):
        """ Calculate the weight vectors, rate, and confidence for the current scenarios
        """
        P, Q = [], []
        for scenario in self.scenarios:
            mask = np.array([scenario.positive_filter(a,
                            scenario.positive_criteria) for a in self.portfolio],
                            dtype=bool)
            pos = self.equilibrium_weights * mask
            if sum(pos) == 0:
                print 'No positive critera match', scenario
                break
            pos = pos / sum(pos)
            mask = np.array([scenario.negative_filter(a,
                            scenario.negative_criteria) for a in self.portfolio],
                            dtype=bool)
            mask[pos > 0] = 0
            neg = self.equilibrium_weights * mask
            if sum(neg) > 0:
                neg = neg / sum(neg)
            P.append(pos - neg)
            Q.append(scenario.excess_return)
        P = np.array(P)
        Q = np.expand_dims(np.array(Q), axis=1)
        V = self.portfolio.covariance_matrix
        Omega = np.dot(np.dot(P, self.tau * V), P.T) * np.eye(Q.shape[0])
        return P, Q, Omega

    @on_trait_change('delta, tau, scenarios.excess_return, portfolio.covariance_matrix')
    def calculate(self):
        """ Optimize portfolio weights for the current scenarios
        """
        if not self.scenarios:
            self.weights = self.equilibrium_weights
            self.expected_returns = self.equilibrium_returns
            return
        P, Q, Omega = self.conditionals
        sigma = self.portfolio.covariance_matrix
        weq = self.equilibrium_weights
        pi = self.equilibrium_returns
        ts = self.tau * sigma
        middle = linalg.inv(np.dot(np.dot(P, ts), P.T) + Omega)
        er = np.expand_dims(pi,axis=0).T + np.dot(np.dot(np.dot(ts, P.T), middle),
                                                  (Q - np.expand_dims(np.dot(P, pi.T),
                                                                      axis=1)))
        posteriorSigma = sigma + ts - ts.dot(P.T).dot(middle).dot(P).dot(ts)
        w = er.T.dot(linalg.inv(self.delta * posteriorSigma)).T
        lmbda = np.dot(linalg.pinv(P).T,(w.T * (1 + self.tau) - weq).T)
        self.weights = w.squeeze()
        self.expected_returns = er.squeeze()
        self.lmbda = lmbda.squeeze()
