""" Traits models for portfolios and assets

Kelsey Jordahl
Time-stamp: <Mon Jul 15 18:30:05 IST 2013>

Copyright (c) 2013, Enthought, Inc.
All rights reserved.
"""
import os
import shelve
from datetime import date, datetime
import re
import urllib2

import numpy as np
from pandas import Series, DataFrame, Panel
from pandas.io.data import DataReader
from pandas.io.pytables import HDFStore

from traits.api import (HasTraits, Date, Float, List, String, Array, Bool, Int,
                        Instance, Property, Tuple, cached_property, Str,
                        Event, on_trait_change)

from portfolio.utils import gunzip_file
from portfolio.data_manager.i_data_manager import IDataManager

_this_dir = os.path.split(os.path.abspath(__file__))[0]
DATA_DIRECTORY = os.path.join(os.path.split(_this_dir)[0], 'data')
ASSETS_CACHE = os.path.join(DATA_DIRECTORY, 'assets.cache')
HDF5FILE = os.path.join(DATA_DIRECTORY, 'history.h5')
START_DATE = date(1980, 1, 1)
END_DATE = datetime.now().date()

DOW_SYMBOLS = ['AA', 'AXP', 'BA', 'BAC', 'CAT', 'CSCO', 'CVX', 'DD', 'DIS',
               'GE', 'HD', 'HPQ', 'IBM', 'INTC', 'JNJ', 'JPM', 'KO', 'MCD',
               'MMM', 'MRK', 'MSFT', 'PFE', 'PG', 'T', 'TRV', 'UNH', 'UTX',
               'VZ', 'WMT', 'XOM']


def cov2corr(cov):
    """ convert a covariance matrix to a correlation matrix

    Return correlation matrix (same size as covariance) and
    standard deviation vector
    """
    N, M = cov.shape
    assert N == M, 'covariance matrix must be square'
    diag = cov.diagonal()
    corr = cov / np.sqrt(np.outer(diag, diag))
    return corr, np.sqrt(diag)


def corr2cov(corr, stdev):
    """ convert a correlation matrix to a covariance matrix

    Arguments: correlation matrix and standard deviation (not variance)
    Returns: covariance matrix (same size as correlation)
    """
    N, M = corr.shape
    assert N == M, 'correlation matrix must be square'
    assert N == len(stdev)
    return corr * np.outer(stdev, stdev)


def date2days(dt):
    """ Return the number of days since the epoch (1-Jan-1970)

        Parameters
        ----------
        dt : date or datetime object

        Returns
        -------
        result : int

    """
    if isinstance(dt, datetime):
        dt = dt.date()
    epoch = date(1970, 1, 1)
    td = dt - epoch
    return td.days


def days2date(days):
    """ Return a date correspending to a number of days since the epoch
        (1-Jan-1970)

        Parameters
        ----------
        result : int

        Returns
        -------
        dt : date or datetime object

    """
    epoch = date(1970, 1, 1)
    return date.fromordinal(epoch.toordinal() + days)


class Asset(HasTraits):
    """ An individual asset

    key: unique key (in our investment universe). May be a ticker symbol
    name: full name
    market_cap: Market capitalization (in billion USD)
    sector: ICB sector name [1]
    industry: ICB industry name [1]
    history: a pandas dataframe of market history time series (close px, volume, etc)

    more metadata could go in here

    [1] Industry Classification Benchmarkl (ICB) info:
        http://www.nyse.com/about/listed/lc_all_industry.html
    """
    key = String
    name = Property(String)
    market_cap = Float
    sector = String
    industry = String
    history = Instance(DataFrame)
    returns = Instance(Series)
    metadata_timestamp = Instance(datetime)

    metadata_changed = Event()

    def _get_name(self):
        if hasattr(self, '_name'):
            return self._name
        else:
            return self.key

    def _set_name(self, name):
        self._name = name

    def __repr__(self):
        return 'Asset(%s)' % self.key

    def __str__(self):
        return self.name

    def update_metadata(self, metadata):
        """ Update asset attributes from a dictionary of metadata

        Naively adds all attributes to the asset, converting to
        numeric values if possible.
        This is somewhat brittle and should be improved.
        """
        # TODO: smart handling of numeric fields
        # TODO: only set known traits?
        # TODO: use property setters to do string format conversion?
        for k, v in metadata.iteritems():
            try:
                v = float(v)
            except:
                if isinstance(v, basestring):
                    # e.g. market_cap in billions
                    m = re.match('(\d+\.?\d)*B', v)
                    if m:
                        try:
                            v = float(m.groups()[0])
                        except:
                            pass
                    else:
                        m = re.match('([+-]\d+.?\d*)%', v)
                        if m:
                            try:
                                v = float(m.groups()[0])
                            except:
                                pass
            setattr(self, k, v)
        self.metadata_changed = (self.metadata_timestamp, metadata)

def filter_by_key(asset, keys):
    """ Utility function to return True if asset is in list of keys
    """
    if isinstance(keys, basestring):
        keys = [keys]
    return asset.key in keys


def filter_by_sector(asset, sectors):
    """ Utility function to return True if asset is in list of sectors
    """
    if isinstance(sectors, basestring):
        sectors = [sectors]
    return asset.sector in sectors


def filter_by_industry(asset, industries):
    """ Utility function to return True if asset is in list of industries
    """
    if isinstance(industries, basestring):
        industries = [industries]
    return asset.industry in industries


def filter_by_market_cap(asset, val):
    """ Utility function to return True if asset has market cap > val
    """
    return asset.market_cap > val


class Portfolio(HasTraits):
    """ A portfolio of assets

    weights may be normallized market caps
    covariance can be calculated from correlation and standard deviation (or vice versa)
    """
    assets = List
    weights = Array
    sectors = Property(List)
    # should this be duplicated here? each Asset has a history DataFrame
    history = Instance(Panel)
    # global earliest and latest dates available
    earliest_date = Date(START_DATE)
    latest_date = Date(END_DATE)
    # dynamically set start and end dates for covariance calculation, etc.
    start_date = Date(START_DATE)
    end_date = Date(END_DATE)
    start_day = Property(Int, depends_on='start_date')
    end_day = Property(Int, depends_on='end_date')
    returns = Property(Array, depends_on='history, start_date, end_date')
    covariance_matrix = Property(Array, depends_on='start_date, end_date, returns')
    # correlation contains correlation matrix and standard deviation as a tuple
    correlation = Property(Tuple(Array, Array), depends_on='covariance_matrix')
    correlation_matrix = Property(Array, depends_on=('correlation'))
    standard_deviation = Property(Array, depends_on=('correlation'))
    static_covariance = Bool(False)
    symbols = List

    asset_updated = Event()

    def update_market_caps(self):
        url = 'http://finance.yahoo.com/d/quotes.csv?s=%s&f=j1' % '+'.join(self.symbols)
        f = urllib2.urlopen(url)
        caps = f.readlines()
        f.close()
        d = {}
        for symbol, cap in zip(self.symbols, caps):
            try:
                d[symbol] = float(cap.strip()[:-1])
            except ValueError:
                print 'Market cap failed for', symbol
                if cap.strip() == 'N/A':
                    d[symbol] = None
                else:
                    d[symbol] = cap.strip()
        for asset in self.assets:
            asset.market_cap = d[asset.key]

    def _symbols_default(self):
        return [asset.key for asset in self.assets]

    def _set_start_day(self, day):
        """ start_date is canonical, setting this property needs to update it
        """
        self.start_date = days2date(day)

    def _get_start_day(self):
        """ Start date as an integer
        """
        return date2days(self.start_date)

    def _set_end_day(self, day):
        """ end_date is canonical, setting this property needs to update it
        """
        self.end_date = days2date(day)

    def _get_end_day(self):
        """ End date as an integer
        """
        return date2days(self.end_date)

    def _get_sectors(self):
        """ return a list of sectors in the portfolio.

        """
        sectors = [asset.sector for asset in self]
        return sorted(list(set(sectors)))

    @on_trait_change('assets:metadata_changed')
    def _asset_metadata_updated(self, object, name, (timestamp, metadata)):
        self.asset_updated = (object, metadata)

    @cached_property
    def _get_returns(self):
        """ Calculate returns given the price history and date window
        """
        # 1 year returns
        # TODO: expose this as trait
        lag = 252
        df = self.history['Adj Close']
        returns = df.shift(-lag) / df - 1
        for asset in self.assets:
            asset.returns = returns[asset.key].truncate(before=self.start_date, after=self.end_date)
        return returns

    def _set_covariance_matrix(self, covar):
        if self.static_covariance:
            self._static_covariance_matrix = covar
        else:
            # should raise exception, but loading pickled portfolio sets this
            #raise AttributeError, 'Cannot set covariance matrix unless static_covariance is True'
            pass

    @cached_property
    def _get_covariance_matrix(self):
        """ Calculate covariance matrix given the price history and date window
        """
        if self.static_covariance:
            return self._static_covariance_matrix
        else:
            rets = self.returns.truncate(before=self.start_date, after=self.end_date)
            return rets.cov().values

    @cached_property
    def _get_correlation(self):
        """ Calculate the correlation matrix and standard deviation
        """
        corr, stdev = cov2corr(self.covariance_matrix)
        return corr, stdev

    def _set_correlation(self, correlation):
        """ Setting the correlation should trigger a calculation of
        the covariance matrix.

        NOTE: No longer possible with dynamically computed covariance matrix.
        """
        #corr, stdev = correlation
        #self.covariance_matrix = corr * np.outer(stdev, stdev)
        pass

    def _get_correlation_matrix(self):
        """ Correlation matrix is the first item in the correlation attribute
        """
        return self.correlation[0]

    def _get_standard_deviation(self):
        """ Standard deviation is the second item in the correlation attribute
        """
        return self.correlation[1]

    def __getitem__(self, idx):
        """ Return an asset by index or key
        """
        if isinstance(idx, basestring):
            # TODO: cache dictionary of keys
            keys = [asset.key for asset in self]
            return self.assets[keys.index(idx)]
        else:
            return self.assets[idx]

    def __repr__(self):
        return 'Portfolio(%s)' % ','.join([asset.key for asset in self.assets])

    def __len__(self):
        return len(self.assets)


class PortfolioLoader(HasTraits):
    """ Creates a portfolio from a list of ticker symbols
    """

    symbols = List(Str)
    portfolio = Instance(Portfolio)
    data_source = Instance(IDataManager)

    hdfstore = Str(HDF5FILE)

    # If metadata timestamp is older than this, it will be refreshed.
    # Set to -1 to force reload always.
    stale_days = 7

    def timestamp_stale(self, timestamp):
        """
        """
        if timestamp is None:
            return True
        delta = datetime.now() - timestamp
        return delta.days > self.stale_days

    def _portfolio_default(self):
        """ Return a Portfolio instance with metadata loaded
        """
        assets = self.fetch_shelved_assets()
        portfolio = Portfolio(assets=assets)
        portfolio.history = self.fetch_yahoo_timeseries(portfolio)
        w = np.array([asset.market_cap for asset in portfolio])
        if sum(w) == 0:
            portfolio.update_market_caps()
            w = np.array([asset.market_cap for asset in portfolio])
        portfolio.weights = w / w.sum()
        for asset in assets:
            asset.close_px = asset.history['Adj Close']
        return portfolio

    def refresh_metadata(self):
        for asset in self.portfolio.assets:
            if self.timestamp_stale(asset.metadata_timestamp):
                self.data_source.get_metadata(asset.key)

    def fetch_data_for(self, ticker):
        self.symbols.append(ticker)
        asset = self.fetch_shelved_asset(ticker)
        self.portfolio.assets.append(asset)
        self.data_source.get_metadata(ticker)

    @on_trait_change('data_source:new_metadata')
    def _new_metadata(self, (symbol, metadata)):
        if symbol in self.symbols:
            self.portfolio[symbol].update_metadata(metadata)
            # only store if metadata is fresh
            delta = datetime.now() - self.portfolio[symbol].metadata_timestamp
            if delta.seconds < 10:
                self.shelve_asset(self.portfolio[symbol])

    def fetch_shelved_asset(self, key, filename=ASSETS_CACHE):
        key = str(key)
        d = shelve.open(filename)
        asset = d.get(key, Asset(key=key))
        d.close()
        return asset

    def shelve_asset(self, asset, filename=ASSETS_CACHE):
        print 'shelving', asset.key
        d = shelve.open(filename)
        d[asset.key] = asset
        d.close()

    def fetch_shelved_assets(self, filename=ASSETS_CACHE):
        """ Fetch a list of assets from the local cache
        """
        print "fetching shelved assets..."
        assets = []
        if not os.path.exists(filename):
            gunzip_file(ASSETS_CACHE)
        d = shelve.open(filename)
        for symbol in self.symbols:
            try:
                asset = d[symbol]
            except KeyError:
                asset = Asset(key=symbol)
            assets.append(asset)
        d.close()
        return assets

    def fetch_yahoo_timeseries(self, portfolio=portfolio, start_time=datetime(1980, 1, 1)):
        """ fetch the timeseries for all names in a portfolio and return
        as a pandas panel

        portfolio is an instance of Portfolio
        """
        store = HDFStore(self.hdfstore)
        print "fetching timeseries..."

        data = {}
        for sym in portfolio.symbols:
            if portfolio[sym].history is not None:
                data[sym] = portfolio[sym].history
            elif sym in store:
                data[sym] = store[sym]
                portfolio[sym].history = data[sym]
            else:
                data[sym] = DataReader(sym, "yahoo", start=start_time)
                store[sym] = data[sym]
                portfolio[sym].history = data[sym]
        history = Panel(data).swapaxes('items', 'minor')
        store['history'] = history
        store.close()
        return history
