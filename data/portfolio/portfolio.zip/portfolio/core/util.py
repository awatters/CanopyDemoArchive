""" Portfolio utilities

Kelsey Jordahl
Time-stamp: <Mon Jul 15 17:09:07 IST 2013>

Copyright (c) 2013, Enthought, Inc.
All rights reserved.
"""
import csv
from datetime import datetime
import os
import shelve
import urllib2

import numpy as np
from pandas import Series, Panel
from pandas.io.data import DataReader
from pandas.io.pytables import HDFStore

from portfolio.core.assets import (
    Asset, Portfolio, corr2cov, ASSETS_CACHE, DATA_DIRECTORY)
from portfolio.utils import gunzip_file


def fetch_market_caps(symbols):
    """ Fetch market caps from Yahoo finance
    Returns a dictionary of caps

    Yahoo magic codes from: http://www.gummy-stuff.org/Yahoo-data.htm
    """
    url = 'http://finance.yahoo.com/d/quotes.csv?s=%s&f=j1' % '+'.join(symbols)
    f = urllib2.urlopen(url)
    caps = f.readlines()
    f.close()
    d = {}
    for symbol, cap in zip(symbols, caps):
        try:
            d[symbol] = float(cap.strip()[:-1])
        except ValueError:
            print 'Market cap failed for', symbol
            if cap.strip() == 'N/A':
                d[symbol] = None
            else:
                d[symbol] = cap.strip()
    return d


def fetch_sectors(symbols):
    """ Get list of sector and industry for each symbol
    Return two lists of length len(symbols)

    Get data from NASDAQ (for both NASDAQ and NYSE symbols).
    See http://stackoverflow.com/questions/11339993/getting-stocks-by-industry-via-yahoo-finance

    More comprehensive NYSE data is available at:
    http://www.nyse.com/indexes/nyaindex.csv
    """
    # TODO: cache these dictionaries
    sector = {}
    industry = {}
    nasdaq_csv = 'nasdaq.csv'
    try:
        f = open(nasdaq_csv, 'r')
    except IOError:
        url = 'http://www.nasdaq.com/screening/companies-by-name.aspx?letter=0&exchange=nasdaq&render=download'
        f = urllib2.urlopen(url)
    reader = csv.reader(f)
    for row in reader:
        sector[row[0]] = row[6]
        industry[row[0]] = row[7]
    # TODO: eliminate duplication here
    nyse_csv = 'nyse.csv'
    try:
        f = open(nyse_csv, 'r')
    except IOError:
        url = 'http://www.nasdaq.com/screening/companies-by-name.aspx?letter=0&exchange=nyse&render=download'
        f = urllib2.urlopen(url)
    reader = csv.reader(f)
    for row in reader:
        sector[row[0]] = row[6]
        industry[row[0]] = row[7]
    sector_list, industry_list = [], []
    for sym in symbols:
        sector_list.append(sector.get(sym, ''))
        industry_list.append(industry.get(sym, ''))
    return sector_list, industry_list


def fetch_libor(symbol=None, start_date=None):
    """ get time series of libor rates from FRED
    Returns a pandas Series
    """
    if symbol is None:
        # 12-month LIBOR: http://research.stlouisfed.org/fred2/series/USD12MD156N
        symbol = 'USD12MD156N'
    if start_date is None:
        start_date = datetime(1986, 1, 1)
    data = DataReader(symbol, "fred", start=start_date)
    # BUG: returns non numeric data (".") in series values
    # which forces values to numpy array of dtype object.
    # workaround by recreating series, excluding non-numeric data
    d = {}
    for ts, val in data[symbol].to_dict().iteritems():
        try:
            rate = float(val)
            d[ts] = rate
        except:
            pass
    return Series(d)


def sample_portfolio():
    """ Return a sample portfolio
    Uses the example from He and Litterman (1999)
    """
    asset_names = ['Australia', 'Canada', 'France', 'Germany', 'Japan', 'UK', 'USA']
    assets = [Asset(key=key) for key in asset_names]
    p = Portfolio(assets=assets, static_covariance=True)
    p.weights = np.array([0.016, 0.022, 0.052, 0.055, 0.116, 0.124, 0.615])
    C = np.array([[1.000, 0.488, 0.478, 0.515, 0.439, 0.512, 0.491],
                      [0.488, 1.000, 0.664, 0.655, 0.310, 0.608, 0.779],
                      [0.478, 0.664, 1.000, 0.861, 0.355, 0.783, 0.668],
                      [0.515, 0.655, 0.861, 1.000, 0.354, 0.777, 0.653],
                      [0.439, 0.310, 0.355, 0.354, 1.000, 0.405, 0.306],
                      [0.512, 0.608, 0.783, 0.777, 0.405, 1.000, 0.652],
                      [0.491, 0.779, 0.668, 0.653, 0.306, 0.652, 1.000]])
    Sigma = np.array([0.160, 0.203, 0.248, 0.271, 0.210, 0.200, 0.187])
    covar = corr2cov(C, Sigma)
    p.covariance_matrix = covar
    return p


def dow_portfolio(filename=ASSETS_CACHE, hdffile='history.h5'):
    """ Return a portfolio for the DJI

    Use cached on disk if available, and save cached copy if fetched from Yahoo.
    """
    assets = []
    symbols = ['AA', 'AXP', 'BA', 'BAC', 'CAT', 'CSCO', 'CVX', 'DD',
               'DIS', 'GE', 'HD', 'HPQ', 'IBM', 'INTC', 'JNJ', 'JPM',
               'KO', 'MCD', 'MMM', 'MRK', 'MSFT', 'PFE', 'PG', 'T',
               'TRV', 'UNH', 'UTX', 'VZ', 'WMT', 'XOM']

    store = HDFStore(os.path.join(DATA_DIRECTORY, hdffile))
    if 'history' in store:
        history = store['history']
    else:
        print 'Fetching history data from Yahoo...'
        history = fetch_yahoo_timeseries(symbols)
        store['history'] = history
    store.close()

    if not os.path.exists(filename):
        gunzip_file(ASSETS_CACHE)
    d = shelve.open(filename)
    for symbol in symbols:
        asset = d.get(symbol, Asset(key=symbol))
        asset.close_px = history['Adj Close'].get(asset.key, None)
        assets.append(asset)
    d.close()
    p = Portfolio(assets=assets, history=history)
    w = np.array([a.market_cap for a in p])
    p.weights = w / sum(w)
    return p


def create_asset_cache(filename=ASSETS_CACHE, csvfile='tickers.csv'):
    """ Create a full list of assets and cache to local storage

    Name, sector, and industry will be populated from local csv files.
    No data is fetched remotely, and other metadata fields are unpopulated.
    """
    assets = []
    for symbol, name in csv.reader(file(os.path.join(DATA_DIRECTORY, csvfile))):
        assets.append(Asset(key=symbol, name=name))
    sectors, industries = fetch_sectors([asset.key for asset in assets])
    for asset, sector, industry in zip(assets, sectors, industries):
        asset.sector = sector
        asset.industry = industry
    shelve_assets(assets)


def shelve_assets(assets, filename=ASSETS_CACHE):
    """ save assets to local datastore

    assets can be a list or a portfolio
    """
    d = shelve.open(filename)
    for asset in assets:
        d[asset.key] = asset
    d.close()


def portfolio_covariance(p, lag=252):
    """ Calculate a covariance matrix for a portfolio.
    It must have a history attribute containing a pandas panel.
    Covariance will be computed on returns of the 'Adj Close' dataframe.
    By default, lag=252 is one-year running returns.

    TODO: This could be a method on a portfolio instance.
    """
    close_px = p.history['Adj Close']
    rets = close_px.shift(-lag) / close_px - 1
    return rets.cov().values


def fetch_yahoo_portfolio(symbols):
    """ Create a portfolio from a list of ticker symbols
    Calls helper functions to get the history and calculate covariance
    for the portfolio.
    """
    assets = []
    url = 'http://finance.yahoo.com/d/quotes.csv?s=%s&f=nj1' % '+'.join(symbols)
    f = urllib2.urlopen(url)
    reader = csv.reader(f)
    for symbol, row in zip(symbols, reader):
        asset = Asset(key=symbol)
        asset.name, cap = row
        try:
            asset.market_cap = float(cap.strip()[:-1])
        except ValueError:
            print 'Market cap failed for', symbol
        assets.append(asset)
    history = fetch_yahoo_timeseries(symbols)
    p = Portfolio(assets=assets, history=history)
    return p


def fetch_yahoo_timeseries(p, start_time=None):
    """ fetch the timeseries for all names in a portfolio and return
    as a pandas panel

    p can be either an instance of portfolio or a list of ticker symbols
    """
    if isinstance(p, Portfolio):
        symbols = [asset.key for asset in p]
    else:
        symbols = p
    if start_time is None:
        start_time = datetime(1980, 1, 1)
    data = dict((sym, DataReader(sym, "yahoo", start=start_time))
                for sym in symbols)
    panel = Panel(data).swapaxes('items', 'minor')
    return panel


if __name__ == '__main__':
    """ Some simple tests
    """
    import matplotlib.pyplot as plt
    dow_symbols = ['AA', 'AXP', 'BA', 'BAC', 'CAT', 'CSCO', 'CVX', 'DD', 'DIS',
                   'GE', 'HD', 'HPQ', 'IBM', 'INTC', 'JNJ', 'JPM', 'KO', 'MCD',
                   'MMM', 'MRK', 'MSFT', 'PFE', 'PG', 'T', 'TRV', 'UNH', 'UTX',
                   'VZ', 'WMT', 'XOM']
    cap_dict = fetch_market_caps(dow_symbols)
    print cap_dict
    libor = fetch_libor()
    libor.plot()
    plt.show()
