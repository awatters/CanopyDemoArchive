import os
import sys
import csv
import pandas, numpy as np
from traits.api import (
    HasTraits, Any, DelegatesTo, Instance, List, Constant, on_trait_change
    )
from traitsui.api import View, Item, TabularEditor
from traitsui.tabular_adapter import TabularAdapter

from portfolio.ui.widgets.grid.pivot import (
    treemap, pivot_selector, pandas_pivot)

from portfolio.core.assets import Portfolio


treemap_dtype = np.dtype(
    [('Name', object),
     ('Sector', object),
     ('Market Cap', float),
     ('% Change', float)])

DATA_PATH = os.path.join(os.path.dirname(__file__), os.pardir, 'data')
CSVFILE = os.path.join(DATA_PATH, 'tickers.csv')

class AssetAdapter(TabularAdapter):

    columns = [('Ticker', 'key'),
               ('Name', 'name'),
               ('Price', 'price'),
               #('% Change', 'percent_change'),
               ('Avg Daily Volumne', 'avg_daily_volume'),
               ('Market Cap', 'market_cap'),
               ('EBITDA', 'ebitda')]

    price_alignment = Constant('right')
    avg_daily_volume_alignment = Constant('right')
    market_cap_alignment = Constant('right')
    ebitda_alignment = Constant('right')

class AssetManager(HasTraits):

    ticker_names = List

    portfolio = Instance(Portfolio)

    assets = DelegatesTo('portfolio')

    treemap = Any()
    pivot_engine = Instance(pandas_pivot.PandasEngine)

    view = View(
        Item('assets',
             editor=TabularEditor(adapter = AssetAdapter(),
                                  operations = [], show_row_titles = False),
             show_label = False,
        ))

    def _get_assets(self):
        return self.portfolio.assets

    def _ticker_names_default(self):
        return [row[0] for row in csv.reader(file(CSVFILE))]

    def get_data(self, ticker):
        self.data_source.get_metadata(ticker)
        #self.data_source.get_price_history(ticker)

    @on_trait_change('portfolio:asset_updated')
    def _asset_updated(self, (asset, metadata)):
        frame = self.pivot_engine.frame

        change = getattr(asset, '50day_moving_avg_change')/100.
        try:
            series = frame.ix[asset.key]
            series['% Change'] = change
            series['Market Cap'] = asset.market_cap if asset.market_cap else 0.01
            frame.ix[asset.key] = series
        except KeyError:
            ar = np.array([(asset.key, asset.sector, asset.market_cap, change)], dtype=treemap_dtype)
            frame = frame.append(pandas.DataFrame(ar))

        self.pivot_engine.frame = frame
        self.pivot_engine.refilter()

    def _pivot_engine_default(self):
        ar = np.array([(asset.key, asset.sector, asset.market_cap if asset.market_cap else 1, 0)
                        for asset in self.assets],dtype=treemap_dtype)
        df = pandas.DataFrame(ar, index=ar['Name'])
        engine = pandas_pivot.PandasEngine(
            aggregates = [('Market Cap', 'sum'), ('% Change', 'mean')],
            row_pivots = ['Sector', 'Name'],
            col_pivots = [],
        )
        engine.frame = df
        return engine

    def _treemap_default(self):
        from enaml.qt.qt.QtGui import QWidget, QHBoxLayout, QVBoxLayout, QToolTip

        engine = self.pivot_engine
        tm = treemap.treemap_view(engine)

        selector = pivot_selector.PivotSelector()
        selector.setSelectors(engine.row_pivots)

        def _update_pivots(sel):
            tm.setDepth(sel+1)

        def _update_treemap(event):
            if event[0] == 'all':
                tm._update()

        def _show_info(name, rect):
            asset = self.portfolio[name]
            info = '<i>%s</i>'%(asset.name)
            QToolTip.showText(tm.mapToGlobal(rect.topLeft()), info, tm, rect)

        engine.on_trait_change(_update_treemap, 'update')

        selector.selectorLevelChanged.connect(_update_pivots)

        tm.rectHovered.connect(_show_info)

        widget = QWidget()
        layout = QHBoxLayout()
        layout.addWidget(selector)
        layout.addStretch()

        l = QVBoxLayout()
        l.addLayout(layout)
        l.addWidget(tm)
        widget.setLayout(l)
        return widget

