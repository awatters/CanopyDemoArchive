import unittest
import numpy as np
from portfolio import Asset, Portfolio, cov2corr, corr2cov


class TestAsset(unittest.TestCase):
    """ Tests for Asset class
    """

    def test_key_only(self):
        """ Test creating an empty asset with a key but no name
        """
        name = 'foo'
        a = Asset(key=name)
        assert a.key == name
        assert a.name == name

    def test_name(self):
        key, name = 'foo', 'bar'
        a = Asset(key=key)
        a.name = name
        assert a.key == key
        assert a.name == name

class TestCorr(unittest.TestCase):
    """ Testing correlation<->covariance functions
    """
    def test_covar(self):
        """ test to see that we get back the random covariance matrix we put in
        after calculating correlation
        """
        N = 30
        covar = np.random.random((N, N))
        corr, std = cov2corr(covar)
        covar2 = corr2cov(corr, std)
        assert np.allclose(covar, covar2)


class TestPortfolio(unittest.TestCase):
    """ Tests for Portfolio class
    """

    def test_hl(self):
        """ Sample correlation matrix from He & Litterman (1999).
        Check that we get back expected covariance.
        """
        C = np.array([[1.000, 0.488, 0.478, 0.515, 0.439, 0.512, 0.491],
                      [0.488, 1.000, 0.664, 0.655, 0.310, 0.608, 0.779],
                      [0.478, 0.664, 1.000, 0.861, 0.355, 0.783, 0.668],
                      [0.515, 0.655, 0.861, 1.000, 0.354, 0.777, 0.653],
                      [0.439, 0.310, 0.355, 0.354, 1.000, 0.405, 0.306],
                      [0.512, 0.608, 0.783, 0.777, 0.405, 1.000, 0.652],
                      [0.491, 0.779, 0.668, 0.653, 0.306, 0.652, 1.000]])
        Sigma = np.array([0.160, 0.203, 0.248, 0.271, 0.210, 0.200, 0.187])
        covar = np.array([[ 0.0256    ,  0.01585024,  0.01896704,  0.0223304 ,  0.0147504 ,
                            0.016384  ,  0.01469072],
                            [ 0.01585024,  0.041209  ,  0.03342842,  0.03603352,  0.0132153 ,
                              0.0246848 ,  0.02957162],
                            [ 0.01896704,  0.03342842,  0.061504  ,  0.05786609,  0.0184884 ,
                              0.0388368 ,  0.03097917],
                            [ 0.0223304 ,  0.03603352,  0.05786609,  0.073441  ,  0.02014614,
                              0.0421134 ,  0.03309208],
                            [ 0.0147504 ,  0.0132153 ,  0.0184884 ,  0.02014614,  0.0441    ,
                              0.01701   ,  0.01201662],
                            [ 0.016384  ,  0.0246848 ,  0.0388368 ,  0.0421134 ,  0.01701   ,
                              0.04      ,  0.0243848 ],
                            [ 0.01469072,  0.02957162,  0.03097917,  0.03309208,  0.01201662,
                              0.0243848 ,  0.034969  ]])
        p = Portfolio(static_covariance=True)
        p.covariance_matrix = covar
        assert np.allclose(C, p.correlation_matrix)
        assert np.allclose(Sigma, p.standard_deviation)

if __name__ == '__main__':
    unittest.main()
