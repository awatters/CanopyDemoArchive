import unittest
import numpy as np
from blacklitterman import BlackLitterman, Scenario
from portfolio import filter_by_key, corr2cov
from util import sample_portfolio


class TestHL(unittest.TestCase):
    """ Tests of Black-Litterman code using examples from He & Litterman (1999)
    """

    def setUp(self):
        p = sample_portfolio()
        self.model = BlackLitterman(portfolio=p)
        s1 = Scenario(excess_return=0.05, name="Germany outperform Europe",
                      positive_filter=filter_by_key, positive_criteria='Germany',
                      negative_filter=filter_by_key, negative_criteria=['UK', 'France'])
        s2 = Scenario(excess_return=0.03, name="Canada outperform USA",
                      positive_filter=filter_by_key, positive_criteria='Canada',
                      negative_filter=filter_by_key, negative_criteria='USA')
        self.scenarios = [s1, s2]

    def test_germany_scenario(self):
        """ Germany +5% scenario from He & Litterman
        Check results for weights, returns, and lambda
        """
        model = self.model
        model.scenarios = [self.scenarios[0]]
        model.calculate()
        self.assertAlmostEqual(float(model.lmbda), 0.3170096024214962)
        assert(np.allclose(model.expected_returns, np.array([0.04328188, 0.0757579, 0.09287498,
                                               0.11037475, 0.04506245, 0.0695287, 0.08069433])))
        assert(np.allclose(model.weights, np.array([0.0152381, 0.02095238, -0.03967803,
                                                    0.35429486, 0.11047619, -0.09461683, 0.58571429])))

    def test_canada_scenario(self):
        """ Canada outperform US by 3% scenario
        """
        model = self.model
        model.scenarios = [self.scenarios[1]]
        model.calculate()
        self.assertAlmostEqual(float(model.lmbda), 0.434675812218)
        assert(np.allclose(model.expected_returns, np.array([0.04061603, 0.08160191, 0.08620114,
                                               0.09341923, 0.04431048, 0.06799788, 0.06982619])))
        assert(np.allclose(model.weights, np.array([0.0152381, 0.43492934, 0.04952381,
                                               0.05238095, 0.11047619, 0.11809524, 0.17173732])))

    def test_both(self):
        """ Combination of Germany and Canada scenarios
        """
        model = self.model
        model.scenarios = self.scenarios
        model.calculate()
        assert(np.allclose(model.lmbda, [0.29782113, 0.41756426]))
        assert(np.allclose(model.expected_returns, np.array([0.04422316, 0.08730004, 0.09479622,
                                               0.11210749, 0.04616431, 0.06971818, 0.07481685])))
        assert(np.allclose(model.weights, np.array([0.0152381, 0.41863263, -0.03427867,
                                                    0.33602012, 0.11047619, -0.08174145, 0.18803404])))


if __name__ == '__main__':
    unittest.main()
