import numpy as np
from scipy.stats import norm
from pandas import Series

from traits.api import (HasTraits, Instance, Property, List, Float, Str, Int,
                        Bool, Range, DelegatesTo,
                        on_trait_change, cached_property)
from enable.api import ColorTrait
from chaco.tools.api import PanTool, DragZoom, ScatterInspector
from chaco.scales.api import CalendarScaleSystem
from chaco.scales_tick_generator import ScalesTickGenerator
from chaco.ticks import ShowAllTickGenerator
from chaco.api import (ArrayPlotData, BaseXYPlot, ScatterPlot, DataRange1D,
                       OverlayPlotContainer, BasePlotContainer, BarPlot,
                       HPlotContainer, GridDataSource, GridMapper,
                       ImageData, CMapImagePlot, DataRange2D, ColorBar,
                       ColormappedScatterPlot, PlotAxis, LinePlot,
                       FilledLinePlot, HorizonPlot, ArrayDataSource,
                       Base1DMapper, LinearMapper, BandedMapper, RdBu as cmap,
                       add_default_axes, add_default_grids,
                       ScatterInspectorOverlay)
from enaml.qt.qt.QtGui import QToolTip, QCursor, QPalette, QColor

from portfolio.core.assets import Asset, Portfolio, date2days
from portfolio.plot.bar_plotter import BarPlotter
from portfolio.plot.discrete import Discrete
from portfolio.CLA import CLA


def cap2marker_size(cap):
    """ Normalize a list (or array) or market caps and return a marker
    size for each
    """
    min_size = 1
    max_size = 10
    cap = np.array(cap)
    cap = (cap - min(cap)) / (max(cap) - min(cap))
    return min_size + np.sqrt(cap) * (max_size - min_size)


def series2array(series):
    """ Convert a pandas time series to x and y arrays for plotting.

    Removes NaNs and converts timestamps to a time in days.

        Parameters
        ----------
        series : pandas.Series

        Returns
        -------
        result : (x, y)
            A 2-tuple of index and value arrays.
            x : time in days since the epoch (negative x is acceptable)
            y : values from original series

    """
    timestamp = series.index
    y = series.values
    #x = np.array([t.toordinal() for t in timestamp])
    # this is a couple of orders of magnitude faster:
    x = timestamp.values.astype('float') / (24 * 3600 * 1e9)
    mask = np.invert(np.isnan(y))
    return x[mask], y[mask]


class TimeSeriesPlotter(HasTraits):
    """ Container for a time series plot
    Currently the plot itself will be provided by ReturnHorizons or PricePlot
    """
    styler = Instance(HasTraits)
    plot = Instance(BasePlotContainer)
    time_series_plot = Property(Instance(BaseXYPlot))
    series = Instance(Series)
    rets = Property(depends_on='series')
    background_color = DelegatesTo('styler')
    index_mapper = DelegatesTo('styler', prefix='date_mapper')
    start_day = DelegatesTo('styler')
    end_day = DelegatesTo('styler')
    line_alpha = Range(0.0, 1.0, 0.7)
    line_width = Float(2.0)

    @on_trait_change('styler:start_date')
    def _update_start_line(self):
        if hasattr(self, '_start_line'):
            self._start_line.index.set_data([self.start_day, self.start_day])

    @on_trait_change('styler:end_date')
    def _update_end_line(self):
        if hasattr(self, '_start_line'):
            self._end_line.index.set_data([self.end_day, self.end_day])

    @on_trait_change('styler:time_plot_type_idx')
    def _update_time_series_plot(self):
        container = self.plot
        plot = self.time_series_plot
        container.remove(self._plot)
        container.add(plot)
        self._plot = plot

    def _get_time_series_plot(self):
        plot_type = self.styler.time_plot_types[self.styler.time_plot_type_idx]
        if plot_type == 'horizon':
            plotter = ReturnHorizons(styler=self.styler, series=self.series)
        else:
            plotter = PricePlot(styler=self.styler, series=self.series)
        return plotter.plot

    def _plot_default(self):
        plot = self.time_series_plot
        unit_value_mapper = LinearMapper(range=DataRange1D(low=0.0, high=1.0))
        start_line = LinePlot(index=ArrayDataSource([self.start_day,
                                                     self.start_day]),
                              value=ArrayDataSource([0.0, 1.0]),
                              line_style='solid',
                              color=(0.0, 1.0, 0.0, self.line_alpha),
                              line_width=self.line_width,
                              index_mapper=self.index_mapper,
                              value_mapper=unit_value_mapper)
        end_line = LinePlot(index=ArrayDataSource([self.end_day,
                                                   self.end_day]),
                              value=ArrayDataSource([0.0, 1.0]),
                              line_style='solid',
                              color=(1.0, 0.0, 0.0, self.line_alpha),
                              line_width=self.line_width,
                              index_mapper=self.index_mapper,
                              value_mapper=unit_value_mapper)
        container = OverlayPlotContainer(padding=(0,0,0,0),
                                         index_mapper=self.index_mapper)
        container.add(plot)
        container.add(start_line)
        container.add(end_line)
        container.bgcolor = 'transparent'
        container.tools.append(PanTool(component=plot,
                                  constrain=True,
                                  constrain_direction="x"))
        container.tools.append(DragZoom(component=plot, axis="index",
                                   restrict_domain=True, drag_button='left',
                                   single_axis=True,
                                   maintain_aspect_ratio=False))
        self._plot = plot
        self._start_line = start_line
        self._end_line = end_line
        return container


class ReturnHorizons(HasTraits):
    """ Provide a horizon plot of returns
    """
    styler = Instance(HasTraits)
    plot = Instance(BaseXYPlot)
    series = Instance(Series)
    rets = Property(depends_on='series')
    background_color = DelegatesTo('styler')
    index_mapper = DelegatesTo('styler', prefix='date_mapper')

    @cached_property
    def _get_rets(self):
        lag = 252                               # 1 year returns
        rets = self.series.shift(-lag) / self.series - 1
        return series2array(rets)

    def _plot_default(self):
        x, y = self.rets
        if self.index_mapper is None:
            self.index_mapper = LinearMapper(range=DataRange1D(low=min(x),
                                                               high=max(x)))
        value_mapper = BandedMapper(range=DataRange1D(low=0.0, high=max(y)))
        color_mapper = cmap(range=DataRange1D(low=min(y), high=min(y)))
        plot = HorizonPlot(index=ArrayDataSource(x), value=ArrayDataSource(y),
                           bgcolor=self.background_color,
                           index_mapper=self.index_mapper,
                           value_mapper=value_mapper,
                           color_mapper=color_mapper)
        return plot


class PricePlot(HasTraits):
    """ Provide a plot of price history
    """
    styler = Instance(HasTraits)
    plot = Instance(BaseXYPlot)
    series = Instance(Series)
    background_color = DelegatesTo('styler')
    fill_color = DelegatesTo('styler', prefix='price_color')
    fill_alpha = DelegatesTo('styler', prefix='price_alpha')
    index_mapper = DelegatesTo('styler', prefix='date_mapper')

    def _fill_color_changed(self):
        self.plot.fill_color = self.fill_color

    def _fill_alpha_changed(self):
        self.plot.alpha = self.fill_alpha

    def _plot_default(self):
        x, y = series2array(self.series)
        if self.index_mapper is None:
            self.index_mapper = LinearMapper(range=DataRange1D(low=min(x),
                                                               high=max(x)))
        value_mapper = LinearMapper(range=DataRange1D(low=0.0, high=max(y)))
        plot = FilledLinePlot(index=ArrayDataSource(x),
                              value=ArrayDataSource(y),
                              bgcolor=self.background_color,
                              fill_color=self.fill_color,
                              alpha=self.fill_alpha,
                              index_mapper=self.index_mapper,
                              value_mapper=value_mapper)
        return plot


class ReturnHist(HasTraits):
    """ Provide a histogram of returns
    TODO: reuse calculated returns for all plots!
    """
    styler = Instance(HasTraits)
    plot = Instance(BasePlotContainer)
    bar_data = Instance(ArrayPlotData)
    asset = Instance(Asset)
    bar_width = Float(1.0)
    background_color = DelegatesTo('styler')
    fill_color = DelegatesTo('styler', prefix='hist_color')
    fill_alpha = DelegatesTo('styler', prefix='hist_alpha')

    def _fill_color_changed(self):
        self._plot.fill_color = self.fill_color

    def _fill_alpha_changed(self):
        self._plot.alpha = self.fill_alpha

    @on_trait_change('asset:returns')
    def _update_hists(self):
        y, x = np.histogram(self.asset.returns, bins=50,
                            range=(-2, 2), density=True)
        self._plot.value.set_data(y)

    def _plot_default(self):
        rets = self.asset.returns
        y, x = np.histogram(rets, bins=50, range=(-2, 2), density=True)
        index_mapper = LinearMapper(range=DataRange1D(low=min(x), high=max(x)))
        value_mapper = LinearMapper(range=DataRange1D(low=0.0, high=max(y)))
        plot = FilledLinePlot(index=ArrayDataSource(x[:-1]),
                              value=ArrayDataSource(y),
                              bgcolor=self.background_color,
                              fill_color=self.fill_color,
                              alpha=self.fill_alpha,
                              index_mapper=index_mapper,
                              value_mapper=value_mapper)
        n = norm.pdf(x, loc=rets.mean(), scale=rets.std())
        refplot = LinePlot(index=ArrayDataSource(x), value=ArrayDataSource(n),
                           line_style='dot',
                           color='red',
                           index_mapper=index_mapper,
                           value_mapper=value_mapper)
        container = OverlayPlotContainer(padding=(0,0,0,0),
                                         index_mapper=index_mapper,
                                         value_mapper=value_mapper)
        container.add(plot)
        container.add(refplot)
        container.bgcolor = 'transparent'
        self._plot = plot
        return container


class QQPlot(HasTraits):
    """ Provide QQ plot of returns against a normal distribution
    TODO: reuse calculated returns for all plots!
    """
    styler = Instance(HasTraits)
    plot = Instance(BasePlotContainer)
    bar_data = Instance(ArrayPlotData)
    asset = Instance(Asset)
    bar_width = Float(1.0)
    background_color = DelegatesTo('styler')
    marker = DelegatesTo('styler', prefix='scatter_marker')
    marker_color = DelegatesTo('styler', prefix='scatter_marker_color')
    marker_size = DelegatesTo('styler', prefix='scatter_marker_size')

    def _marker_changed(self):
        # passed as unicode; could validate in enaml instead
        self.plot.marker = str(self.marker)

    def _marker_size_changed(self):
        self.plot.marker_size = self.marker_size

    def _qq(self):
        """ Calculate the observed distribution vs. normal distribution
        """
        rets = self.asset.returns
        y, x = np.histogram(rets, bins=50, range=(-2, 2), density=True)
        x = x[:-1] + 0.5 * (x[1] - x[0])
        n = norm.cdf(x, loc=rets.mean(), scale=rets.std())
        y = np.cumsum(y)
        y = y / max(y)
        return n, y

    @on_trait_change('asset:returns')
    def _update_hists(self):
        n, y = self._qq()
        self._plot.index.set_data(n)
        self._plot.value.set_data(y / max(y))

    def _plot_default(self):
        n, y = self._qq()
        index_mapper = LinearMapper(range=DataRange1D(low=min(n), high=max(n)))
        value_mapper = LinearMapper(range=DataRange1D(low=0.0, high=max(y)))
        plot = ScatterPlot(index=ArrayDataSource(n), value=ArrayDataSource(y),
                           bgcolor=self.background_color,
                           marker=self.marker,
                           marker_size=self.marker_size,
                           color=self.marker_color,
                           outline_color=self.marker_color,
                           index_mapper=index_mapper,
                           value_mapper=value_mapper)
        refplot = LinePlot(index=ArrayDataSource([0, 1]),
                           value=ArrayDataSource([0, 1]),
                           line_style='dot',
                           color='gray',
                           index_mapper=index_mapper,
                           value_mapper=value_mapper)
        container = OverlayPlotContainer(padding=(0,0,0,0),
                                         index_mapper=index_mapper,
                                         value_mapper=value_mapper)
        container.add(plot)
        container.add(refplot)
        container.bgcolor = 'transparent'
        self._plot = plot
        return container


class PlotManager(HasTraits):

    model = Instance(HasTraits)
    portfolio = Instance(Portfolio)
    start_date = DelegatesTo('portfolio')
    start_day = DelegatesTo('portfolio')
    end_date = DelegatesTo('portfolio')
    end_day = DelegatesTo('portfolio')

    asset_ds = Instance(ArrayDataSource, {'sort_order': 'ascending'})
    weight_plotter = Instance(BarPlotter)
    weight_bar = Instance(BasePlotContainer)
    return_plotter = Instance(BarPlotter)
    eq_weight_plotter = Instance(BarPlot)
    eq_return_plotter = Instance(BarPlot)
    return_bar = Instance(BasePlotContainer)

    risk_ds = Instance(ArrayDataSource, ())
    risk_return_plot = Instance(BasePlotContainer)
    sharpe_plot = Instance(BasePlotContainer)
    corr_plot = Instance(BasePlotContainer)
    labels = List
    time_series_plotters = List(Instance(HasTraits))
    time_series_plots = Property(List(Instance(BasePlotContainer)),
                                 depends_on='time_plot_type_idx')
    time_series_axis = Instance(BasePlotContainer)
    return_plotters = List(Instance(HasTraits))
    return_plots = List(Instance(BasePlotContainer))
    scatter_plotters = List(Instance(HasTraits))
    scatter_plots = List(Instance(BasePlotContainer))
    time_plot_types = List(['price', 'horizon'])
    time_plot_type_idx = Int(1)
    date_mapper = Instance(Base1DMapper)
    return_mapper = Instance(Base1DMapper)
    # If live_frontier is True, update efficient frontier continuously
    live_frontier = Bool(False)

    # styling parameters
    styling_controls = Bool(False)
    plot_size = Int(50)
    # padding for central plots
    padding = (60, 20, 20, 50)
    # this background color matches enaml's default (on OS X)
    background_color = ColorTrait((0.9294, 0.9294, 0.9294))
    page_color = ColorTrait('lightgray')
    hist_alpha = Range(0.0, 1.0, 0.5)
    hist_color = Str('blue')
    price_alpha = Range(0.0, 1.0, 0.5)
    price_color = Str('green')
    scatter_marker = Str('circle')
    scatter_marker_color = Str('blue')
    scatter_marker_size = Range(0.0, 15.0, 1.5)
    frontier_color = ColorTrait((1.0, 0.0, 0.0, 0.7))

    def _date_mapper_default(self):
        # TODO: set start and end dates dynamically
        start = date2days(self.portfolio.earliest_date)
        end = date2days(self.portfolio.latest_date)
        return LinearMapper(range=DataRange1D(low=start, high=end))

    @on_trait_change('date_mapper:updated')
    def _update_ts_axis(self):
        """ Translate the updated date axis to seconds for the axis header
        """
        start = self.date_mapper.range.low * 24 * 60 * 60
        end = self.date_mapper.range.high * 24 * 60 * 60
        r = self.time_series_axis._mapper.range
        r.low = start
        r.high = end

    def _time_series_plotters_default(self):
        return [TimeSeriesPlotter(series=asset.close_px, styler=self)
                for asset in self.portfolio]

    def _get_time_series_plots(self):
        return [plotter.plot for plotter in self.time_series_plotters]

    def _return_plotters_default(self):
        return [ReturnHist(asset=asset, styler=self)
                for asset in self.portfolio]

    def _return_plots_default(self):
        return [plotter.plot for plotter in self.return_plotters]

    def _scatter_plotters_default(self):
        return [QQPlot(asset=asset, styler=self) for asset in self.portfolio]

    def _scatter_plots_default(self):
        return [plotter.plot for plotter in self.scatter_plotters]

    def _labels_default(self):
        return [asset.key for asset in self.model.portfolio]

    def tick_label(self, x):
        return self.portfolio.symbols[int(x)]

    def _time_series_axis_default(self):
        """ returns a standalone time series axis to be used as a column header
        """
        # TODO: I don't know why I need to append the axis to a dummy plot
        # a standalone PlotAxis should be possible
        start = self.start_day * 24 * 60 * 60
        end = self.end_day * 24 * 60 * 60
        value_mapper = LinearMapper(range=DataRange1D(low=0, high=10))
        date_mapper = LinearMapper(range=DataRange1D(low=start,
                                                     high=end))
        index = ArrayDataSource(np.array([]))
        value = ArrayDataSource(np.array([]))
        plot = ScatterPlot(index=index, value=value,
                           index_mapper=date_mapper,
                           value_mapper=value_mapper,
                           bgcolor='white',
                           padding=(0,0,20,0))
        axis = PlotAxis(component=plot, orientation='top',
                         mapper=date_mapper,
                         bgcolor='white',
                         tick_generator=ScalesTickGenerator(scale=CalendarScaleSystem()))
                         #tick_interval=1,
                         #tick_label_formatter=self.tick_label,
                         #tick_label_alignment='edge',
                         #tick_label_rotate_angle=90,
                         #tick_generator=ShowAllTickGenerator(positions=np.arange(N)))
        container = OverlayPlotContainer(use_backbuffer=True,
                                   bgcolor=self.background_color)
        plot.tools.append(PanTool(component=plot,
                                  constrain=True,
                                  constrain_direction="x"))
        plot.tools.append(DragZoom(component=plot, axis="index",
                                   restrict_domain=True, drag_button='left',
                                   single_axis=True,
                                   maintain_aspect_ratio=False))
        plot.overlays.append(axis)
        container.add(plot)
        container._mapper = plot.index_mapper
        return container
    #return axis

    def _corr_plot_default(self):
        value_range = DataRange1D(low=-1, high=1)
        color_mapper = cmap(range=value_range)

        N = len(self.portfolio)
        index = GridDataSource()
        value = ImageData()
        mapper = GridMapper(range=DataRange2D(index),
                            y_low_pos=1.0, y_high_pos=0.0)
        index.set_data(xdata=np.arange(-0.5, N),
                       ydata=np.arange(-0.5, N))
        value.set_data(np.flipud(self.portfolio.correlation_matrix))
        self.corr_data = value
        cmap_plot = CMapImagePlot(
            index=index,
            index_mapper=mapper,
            value=value,
            value_mapper=color_mapper,
            padding=(40, 40, 100, 40)
        )

        yaxis = PlotAxis(cmap_plot, orientation='left',
                         tick_interval=1,
                         tick_label_formatter=lambda x: self.tick_label(29 - x),
                         tick_generator=ShowAllTickGenerator(positions=np.arange(N)))
        xaxis = PlotAxis(cmap_plot, orientation='top',
                         tick_interval=1,
                         tick_label_formatter=self.tick_label,
                         tick_label_alignment='edge',
                         tick_label_rotate_angle=90,
                         tick_generator=ShowAllTickGenerator(positions=np.arange(N)))
        cmap_plot.overlays.append(yaxis)
        cmap_plot.overlays.append(xaxis)

        colorbar = ColorBar(index_mapper=LinearMapper(range=cmap_plot.value_range),
                            plot=cmap_plot,
                            orientation='v',
                            resizable='v',
                            width=10,
                            padding=(40, 5, 100, 40))

        # Create a container to position the plot and the colorbar side-by-side
        container = HPlotContainer(use_backbuffer=True,
                                   padding=(0, 0, 0, 0),
                                   bgcolor=self.background_color)
        container.add(cmap_plot)
        container.add(colorbar)

        return container

    def _efficient_frontier(self):
        r = np.atleast_2d(self.model.expected_returns).T
        lb = np.zeros(r.shape)
        ub = np.ones(r.shape)
        cla = CLA.CLA(r,
                      self.portfolio.covariance_matrix,
                      lb, ub)
        cla.solve()
        mu, sigma, weights = cla.efFrontier(200)
        return np.array(sigma[::-1]) * 100, np.array(mu[::-1]) * 100

    @on_trait_change('portfolio.standard_deviation')
    def _update_scatter_indices(self, name, new):
        if name == 'standard_deviation':
            self.risk_ds.set_data(new * 100)

    def _risk_return_plot_default(self):
        ret = self.model.expected_returns * 100
        value = ArrayDataSource(ret)
        sectors = list(set(self.portfolio.sectors))
        color_index = [sectors.index(asset.sector) for asset in self.portfolio]
        color_ds = ArrayDataSource(color_index)
        marker = 'circle'
        background_color = 'white'
        color = (1.0, 0.0, 0.0, 0.4)
        fill_alpha = 0.4
        marker_size = cap2marker_size([a.market_cap for a in self.portfolio])
        index_mapper = LinearMapper(range=DataRange1D(self.risk_ds, tight_bounds=False))
        if self.return_mapper is None:
            self.return_mapper = LinearMapper(range=DataRange1D(value, tight_bounds=False))
        color_mapper = Discrete(range=DataRange1D(low=0, high=max(color_index)))
        scatter = ColormappedScatterPlot(index=self.risk_ds, value=value,
                                          bgcolor=background_color,
                           marker=marker, marker_size=marker_size,
                           fill_alpha=fill_alpha,
                           color_data=color_ds,
                           color_mapper=color_mapper,
                           index_mapper=index_mapper,
                           value_mapper=self.return_mapper,
                           border_visible=True,
                           padding=self.padding)
        opt_risk, opt_return = self._efficient_frontier()
        index = ArrayDataSource(opt_risk)
        value = ArrayDataSource(opt_return)
        frontier = LinePlot(index=index, value=value,
                              line_style='dash',
                              bgcolor=background_color,
                              color=self.frontier_color,
                              line_width=2,
                              index_mapper=index_mapper,
                              value_mapper=self.return_mapper,
                              padding=self.padding)
        pret = np.array([self.model.overall_expected_return * 100])
        prisk = np.array([self.model.stdev * 100])
        index = ArrayDataSource(prisk)
        value = ArrayDataSource(pret)
        total = ScatterPlot(index=index, value=value,
                            marker='plus',
                            marker_size=8,
                            color='red',
                            bgcolor=background_color,
                            index_mapper=index_mapper,
                            value_mapper=self.return_mapper,
                            padding=self.padding)
        left, bottom = add_default_axes(scatter)
        hgrid, vgrid = add_default_grids(scatter)
        bottom.title = 'Risk (std, %)'
        left.title = 'Expected Return (%)'
        scatter.tools.append(ScatterInspector(scatter, selection_mode='off'))
        scatter.overlays.append(
            ScatterInspectorOverlay(scatter,
                hover_color="transparent",
                hover_marker_size=10,
                hover_outline_color="blue",
                hover_line_width=2,
                # odd that this needs to be specified.
                # I don't really like the behavior on click.
                selection_marker_size=8,
                selection_color = color)
            )
        plot = OverlayPlotContainer(use_backbuffer=True,
                                   bgcolor=self.background_color)
        plot.add(scatter)
        plot.add(total)
        plot.add(frontier)
        plot._scatter = scatter
        plot._frontier = frontier
        plot._total = total
        return plot

    @on_trait_change('risk_ds:metadata_changed, asset_ds:metadata_changed')
    def _risk_metadata_handler(self, ds, name, new):
        hover_indices = ds.metadata.get('hover', [])
        if hover_indices:
            idx = hover_indices[0]
            text = '<center>%s<br><i>%s</i></center>' % (self.portfolio[idx].name,
                                                         self.portfolio[idx].sector)
            palette = QPalette()
            palette.setColor(palette.ToolTipBase, QColor('black'))
            palette.setColor(palette.ToolTipText, QColor('white'))
            QToolTip.setPalette(palette)
            QToolTip.showText(QCursor.pos(), text)

            # Highlight corresponding bar or scatter plots
            if ds == self.risk_ds:
                self.asset_ds.metadata['hover'] = [idx]
            else:
                self.risk_ds.metadata['hover'] = [idx]

    def _sharpe_plot_default(self):
        sr = self.model.sharpe_ratio
        value = ArrayDataSource(sr)
        sectors = list(set(self.portfolio.sectors))
        color_index = [sectors.index(asset.sector) for asset in self.portfolio]
        color_ds = ArrayDataSource(color_index)
        marker = 'circle'
        background_color = 'white'
        fill_alpha = 0.4
        color = (1.0, 0.0, 0.0, 0.4)
        marker_size = cap2marker_size([a.market_cap for a in self.portfolio])
        index_mapper = LinearMapper(range=DataRange1D(self.risk_ds, tight_bounds=False))
        value_mapper = LinearMapper(range=DataRange1D(value, tight_bounds=False))
        color_mapper = Discrete(range=DataRange1D(low=0, high=max(color_index)))
        scatter = ColormappedScatterPlot(index=self.risk_ds, value=value,
                                          bgcolor=background_color,
                           marker=marker, marker_size=marker_size,
                           fill_alpha=fill_alpha,
                           color_data=color_ds,
                           color_mapper=color_mapper,
                           index_mapper=index_mapper,
                           value_mapper=value_mapper,
                           border_visible=True,
                           padding=self.padding)
        left, bottom = add_default_axes(scatter)
        hgrid, vgrid = add_default_grids(scatter)
        bottom.title = 'Risk (std, %)'
        left.title = 'Sharpe Ratio'
        scatter.tools.append(ScatterInspector(scatter, selection_mode='off'))
        scatter.overlays.append(
            ScatterInspectorOverlay(scatter,
                hover_color="transparent",
                hover_marker_size=10,
                hover_outline_color="blue",
                hover_line_width=2,
                selection_marker_size=8,
                selection_color=color)
            )
        plot = OverlayPlotContainer(bgcolor=self.background_color)
        plot.add(scatter)
        plot._sharpe = scatter
        return plot

    def _weight_plotter_default(self):
        return BarPlotter(labels=self.labels, title='Asset Weights',
                          index_ds=self.asset_ds)

    def _eq_weight_plotter_default(self):
        offset = -0.2
        bar_width = 0.4
        color = (0.0, 0.0, 1.0, 0.3)
        eq_returns = self.model.equilibrium_weights
        value = ArrayDataSource(eq_returns)
        index = ArrayDataSource(np.arange(len(eq_returns)) + offset)
        index_mapper = LinearMapper(range=DataRange1D(low=-1,
                                                      high=len(eq_returns)))
        bar = BarPlot(index=index, value=value, bar_width=bar_width,
                 line_width=0,
                 fill_color=color,
                 index_mapper=index_mapper,
                 value_mapper=self.return_mapper,
                 bgcolor=self.background_color,
                 border_visible=True,
                 padding=(60, 20, 20, 50))
        return bar

    def _weight_bar_default(self):
        self._update_plot_weights()
        plot = self.weight_plotter.plot
        bar2 = self.eq_weight_plotter
        bar2.value_mapper = plot._bar.value_mapper
        plot.add(bar2)
        return plot

    @on_trait_change('model:weights')
    def _update_plot_weights(self):
        self.weight_plotter.value_ds.set_data(self.model.weights)

    def _return_plotter_default(self):
        return BarPlotter(title='Expected Return (%)',
                          offset=0.2,
                          index_ds=self.asset_ds,
                          labels=self.labels)

    def _eq_return_plotter_default(self):
        offset = -0.2
        bar_width = 0.4
        color = (0.0, 0.0, 1.0, 0.3)
        eq_returns = self.model.equilibrium_returns * 100
        value = ArrayDataSource(eq_returns)
        index = ArrayDataSource(np.arange(len(eq_returns)) + offset)
        index_mapper = LinearMapper(range=DataRange1D(low=-1,
                                                      high=len(eq_returns)))
        bar = BarPlot(index=index, value=value, bar_width=bar_width,
                 line_width=0,
                 fill_color=color,
                 index_mapper=index_mapper,
                 value_mapper=self.return_mapper,
                 bgcolor=self.background_color,
                 border_visible=True,
                 padding=(60, 20, 20, 50))
        return bar

    def _return_bar_default(self):
        self._update_plot_returns()
        self.return_plotter.title = 'Expected Return (%)'
        # plot = OverlayPlotContainer(use_backbuffer=True,
        #                            bgcolor=self.background_color)
        plot = self.return_plotter.plot
        bar2 = self.eq_return_plotter
        bar2.value_mapper = plot._bar.value_mapper
        plot.add(bar2)
        return plot

    def update_frontier(self):
        frontier = self.risk_return_plot._frontier
        opt_risk, opt_return = self._efficient_frontier()
        frontier.index.set_data(opt_risk)
        frontier.value.set_data(opt_return)

    def _clear_frontier(self):
        frontier = self.risk_return_plot._frontier
        frontier.index.set_data(np.array([]))
        frontier.value.set_data(np.array([]))


    @on_trait_change('model:expected_returns')
    def _update_plot_returns(self):
        ret = self.model.expected_returns * 100
        self.return_plotter.value_ds.set_data(ret)
        scatter = self.risk_return_plot._scatter
        scatter.value.set_data(ret)
        # this shouldn't be necessary, but mappers aren't synced:
        if self.return_mapper is None:
            print 'none'
        else:
            r = self.return_mapper.range
            low, high = min(ret), max(ret)
            if high > r.high:
                r.high = high
            if low < r.low:
                r.low = low
        pret = np.array([self.model.overall_expected_return * 100])
        prisk = np.array([self.model.stdev * 100])
        overall = self.risk_return_plot._total
        overall.index.set_data(prisk)
        overall.value.set_data(pret)
        self._clear_frontier()
        sharpe = self.sharpe_plot._sharpe
        sharpe.value.set_data(self.model.sharpe_ratio)

    def _update_corr_matrix(self):
        self.corr_data.set_data(np.flipud(self.portfolio.correlation_matrix))
        risk = self.portfolio.standard_deviation * 100
        scatter = self.risk_return_plot._scatter
        scatter.index.set_data(risk)
        sharpe = self.sharpe_plot._sharpe
        sharpe.index.set_data(risk)

    @on_trait_change('portfolio:start_date, portfolio:end_date')
    def _update_time_window(self):
        self._update_corr_matrix()
