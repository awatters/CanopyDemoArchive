""" Bar plotting class

Kelsey Jordahl
Time-stamp: <Mon Mar  4 14:01:43 EST 2013>

Copyright (c) 2013, Enthought, Inc.
All rights reserved.
"""
import numpy as np

from traits.api import (
    HasTraits, Instance, List, Array, Float, String, Bool, on_trait_change
    )
from enable.api import ColorTrait
from chaco.ticks import ShowAllTickGenerator
from chaco.api import (DataRange1D, BarPlot, PlotAxis,
                       ArrayDataSource, LinearMapper, Base1DMapper,
                       BasePlotContainer, OverlayPlotContainer)
from chaco.tools.api import SelectTool


class BarInspector(SelectTool):

    # The names of the data source metadata for hover and selection.
    hover_metadata_name = String('hover')
    selection_metadata_name = String('selections')

    #------------------------------------------------------------------------
    # Override/configure inherited traits
    #------------------------------------------------------------------------
    visible = False

    # This tool does not have a visual reprentation
    draw_mode = "none"

    selection_mode = "off"

    def normal_mouse_move(self, event):
        """ Handles the mouse moving when the tool is in the 'normal' state.

        If the cursor is within **threshold** of a data point, the method
        writes the index to the plot's data sources' "hover" metadata.
        """
        plot = self.component
        index = plot.map_index((event.x, event.y), index_only=True, threshold=self.threshold)
        if index is not None:
            plot.index.metadata[self.hover_metadata_name] = [index]
        else:
            plot.index.metadata.pop(self.hover_metadata_name, None)
        return

class BarPlotter(HasTraits):

    plot = Instance(BasePlotContainer)
    background_color = ColorTrait('white')

    index_ds = Instance(ArrayDataSource) #, {'sort_order': 'ascending'})
    value_ds = Instance(ArrayDataSource, ())
    labels = List
    title = String
    bar_width = Float(0.4)
    color = ColorTrait((1.0, 0.0, 0.0, 0.6))
    offset = Float(0.0)

    hover_index_ds = Instance(ArrayDataSource, {'sort_order': 'ascending'})
    hover_value_ds = Instance(ArrayDataSource, ())

    def _plot_default(self):
        color = (1.0, 0.0, 0.0, 0.6)

        numdata = len(self.value_ds.get_data())
        index = np.arange(numdata)+self.offset
        self.index_ds.set_data(index)

        value_mapper = LinearMapper(range=DataRange1D(self.value_ds, tight_bounds=False))
        index_mapper = LinearMapper(
            range=DataRange1D(self.index_ds, low=-1, high=numdata, tight_bounds=True))

        bar = BarPlot(index=self.index_ds, value=self.value_ds, bar_width=self.bar_width,
                 line_width=0,
                 fill_color=color,
                 index_mapper=index_mapper,
                 value_mapper=value_mapper,
                 bgcolor=self.background_color,
                 border_visible=True,
                 padding=(60, 20, 20, 50))

        label_axis = PlotAxis(bar, tick_label_rotation=90, orientation='bottom',
                               tick_interval=1, positions=index,
                               tick_label_alignment='edge',
                               tick_label_rotate_angle=90,
                               tick_label_formatter=lambda x: self.labels[int(x)],
                               tick_generator=ShowAllTickGenerator(positions=index))
        y_axis = PlotAxis(bar,
                          orientation='left',
                          title=self.title)
        bar.overlays.append(label_axis)
        bar.overlays.append(y_axis)
        bar.tools.append(BarInspector(bar))

        bar_hover = BarPlot(index=self.hover_index_ds, value=self.hover_value_ds,
                bar_width=self.bar_width*1.2,
                fill_color=color,
                index_mapper=index_mapper,
                value_mapper=value_mapper,
                bgcolor=self.background_color,
                border_visible=False,
                padding=(60, 20, 20, 50))

        plot = OverlayPlotContainer(bgcolor=self.background_color)
        plot.add(bar)
        plot.add(bar_hover)
        plot._bar = bar
        return plot

    @on_trait_change('index_ds:metadata_changed')
    def _metadata_handler(self):
        hover_indices = self.index_ds.metadata.get('hover', [])
        if hover_indices:
            self.hover_index_ds.set_data(self.index_ds.get_data()[hover_indices])
            self.hover_value_ds.set_data(self.value_ds.get_data()[hover_indices])
        else:
            self.hover_index_ds.set_data([])
            self.hover_value_ds.set_data([])
