from chaco.api import ColorMapper


def discrete_cmap_generator(colors, N):
    """ Generate a discrete chaco colormap from a set of RGB triplets
    """
    assert N <= len(colors), 'Only %d colors available in color map' % len(colors)
    colors = colors[:N]
    r, g, b = zip(*colors)
    _data = {'red' : [(i / (N - 1.0), v/255.0, v/255.0) for i, v in enumerate(r)],
             'green' : [(i / (N - 1.0), v/255.0, v/255.0) for i, v in enumerate(g)],
             'blue' : [(i / (N - 1.0), v/255.0, v/255.0) for i, v in enumerate(b)]}
    return _data


def Dark2(range, **traits):
    """ Generator function for a discrete colormap.

    RGB triplets from ColorBrewer (http://colorbrewer2.com)
    Qualitative color scheme Dark2
    """
    N = int(range.high + 1)
    colors = [(27, 158, 119), (217, 95, 2), (117, 112, 179),
              (231, 41, 138), (102, 166, 30), (230, 171, 2),
              (166, 118, 29), (102, 102, 102)]
    data = discrete_cmap_generator(colors, N)
    return ColorMapper.from_segment_map(data, range=range, **traits)


def Discrete(range, **traits):
    """ discrete colors for N=10, color space="Intense", soft (k-Means)
    from http://tools.medialab.sciences-po.fr/iwanthue
    """
    N = int(range.high + 1)
    colors = [(77, 156, 139), (202, 86, 203), (191, 77, 59), (104, 74, 105),
              (109, 176, 68), (86, 99, 44), (194, 141, 57), (201, 86, 133),
              (126, 149, 196), (120, 104, 196)]
    data = discrete_cmap_generator(colors, N)
    return ColorMapper.from_segment_map(data, range=range, **traits)
