import threading

# Enthought imports
import enaml
from enaml.qt.qt_application import QtApplication
from enaml.stdlib.sessions import SimpleSession

# Local imports
from portfolio.plot.plot_manager import PlotManager
from portfolio.data_manager.async_loader import AsyncLoader
from portfolio.data_manager.yahoo_finance import YahooDataManager
from portfolio.core.asset_manager import AssetManager
from portfolio.core.blacklitterman import BlackLitterman, Scenario
from portfolio.core.assets import filter_by_key, filter_by_sector, PortfolioLoader
from portfolio.ui.widgets.api import register_widgets

from IPython.frontend.terminal.embed import InteractiveShellEmbed

# If DEBUG is True, open an ipython shell in the terminal
DEBUG = False


class MySession(SimpleSession):
    widget_groups = ['portfolio', 'default']


def run_from_ipython():
    """ Determine whether run from an ipython environment
    """
    try:
        return __IPYTHON__
    except NameError:
        return False


def get_model(portfolio):
    model = BlackLitterman(portfolio=portfolio)
    s1 = Scenario(excess_return=0.02,
                  positive_filter=filter_by_key, positive_criteria='INTC',
                  negative_filter=filter_by_key, negative_criteria='MSFT')
    s2 = Scenario(excess_return=0.03,
                  positive_filter=filter_by_sector, positive_criteria='Finance',
                  negative_filter=filter_by_sector, negative_criteria='Technology')
    s3 = Scenario(positive_filter=filter_by_key, positive_criteria='XOM',
                  negative_filter=filter_by_sector, negative_criteria='Energy')
    s4 = Scenario(name='Small cap outperform large cap',
                  positive_filter=lambda x, y: x.market_cap < y, positive_criteria=150,
                  negative_filter=lambda x, y: x.market_cap > y, negative_criteria=150)
    model.scenarios = [s1, s2, s3, s4]
    model.calculate()
    return model


def start_ipython(model, portfolio, plot_manager):
    shell = InteractiveShellEmbed()
    shell()


def run_application():
    bgcolor = 'white'
    register_widgets()

    # Start up asynchronous data loader
    loader = AsyncLoader()
    loader.start()

    symbols = ['AA', 'AXP', 'BA', 'BAC', 'CAT', 'CSCO', 'CVX', 'DD',
               'DIS', 'GE', 'HD', 'HPQ', 'IBM', 'INTC', 'JNJ', 'JPM',
               'KO', 'MCD', 'MMM', 'MRK', 'MSFT', 'PFE', 'PG', 'T',
               'TRV', 'UNH', 'UTX', 'VZ', 'WMT', 'XOM']

    data_source = YahooDataManager(loader=loader)
    # the main portfolio loader (wired to actual model portfolio)
    pl = PortfolioLoader(symbols=symbols,
                         data_source=data_source,
                         stale_days=-1)
    # a dummy portfolio loader, to load assets but not update live portfolio
    dummy_pl = PortfolioLoader(symbols=symbols[:-2],
                               data_source=data_source,
                               stale_days=-1)

    portfolio = pl.portfolio
    manager = AssetManager(portfolio=dummy_pl.portfolio)
    model = get_model(portfolio)
    plot_manager = PlotManager(portfolio=portfolio, model=model, background_color=bgcolor)

    with enaml.imports():
        from portfolio.ui.app import Main

    factory = MySession.factory('portfolio', 'Portfolio Demo',
                                lambda: Main(manager=manager,
                                        plot_manager=plot_manager,
                                        portfolio=portfolio,
                                        model=model,
                                        loader=dummy_pl))
    if QtApplication.instance():
        app = QtApplication.instance()
        app.add_factories([factory])
    else:
        app = QtApplication([factory])
    session_id = app.start_session('portfolio')
    session = app.session(session_id)

    if DEBUG:
        thread = threading.Thread(target=start_ipython,
                                  args=(model, portfolio, plot_manager))
        thread.daemon = True
        thread.start()

    for window in session.windows:
        window.send_to_front()

    if run_from_ipython():
        pass
    else:
        app.start()
        app.destroy()

if __name__ == '__main__':
    run_application()
