import gzip
import os

def gunzip_file(filename):
    """ Replicates the behaviour of a basic call to gunzip. """

    if filename.endswith('.gz'):
        name, extension = os.path.splitext(filename)
    else:
        name = filename
        filename = '{}.gz'.format(filename)

    with open(name, 'wb') as fh:
        zipfh = gzip.open(filename, 'rb')
        fh.write(zipfh.read())
        zipfh.close()

    # replicate the behaviour of gunzip
    os.unlink(filename)

